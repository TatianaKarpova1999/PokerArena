import './faq.js'
import './swiper-reviews.js'
import './scroll.js'
import './burger.js'